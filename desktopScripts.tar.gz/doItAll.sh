#!/bin/bash

/home/petem/Desktop/runNGServe.sh
/home/petem/Desktop/modularTrackerVSCode.sh
/home/petem/Desktop/openModTrackerFolder.sh


#gnome-terminal -- bash -c "/home/petem/Desktop/modularTrackerVSCode.sh; exec bash"
#gnome-terminal -- bash -c "/home/petem/Desktop/openModTrackerFolder.sh; exec bash"
#gnome-terminal -- bash -c "/home/petem/Desktop/openTerminalToModTrackerFolder.sh; exec bash" 
gnome-terminal --working-directory=/home/petem/Documents/modularTracker/modularTracker
