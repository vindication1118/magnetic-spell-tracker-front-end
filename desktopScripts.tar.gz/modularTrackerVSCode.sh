#!/bin/bash
code /home/petem/Documents/modularTracker/modularTracker && exit
