#!/bin/bash
. ~/.nvm/nvm.sh
. ~/.profile
. ~/.bashrc
export PATH="$HOME/.npm-global/bin:$PATH"
cd /home/petem/Documents/modularTracker/modularTracker
ng serve
