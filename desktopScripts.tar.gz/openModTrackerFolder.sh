#!/bin/bash
cd /home/petem/Documents/modularTracker/modularTracker
nohup nautilus . & disown
