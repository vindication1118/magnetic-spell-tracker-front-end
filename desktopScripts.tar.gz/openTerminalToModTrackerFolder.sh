#!/bin/bash
cd /home/petem/Documents/modularTracker/modularTracker
