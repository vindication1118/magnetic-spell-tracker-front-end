#!/bin/bash
gnome-terminal -- bash -c "/home/petem/Desktop/ngServeModTracker.sh; exec bash"
